#!/usr/bin/perl

$f = shift @ARGV;
open(F,$f);

while(<F>)
{
    chop;
    @in = split;
    $n = 0 + @in;
    for($i=0;$i<$n;$i+=2)
    {
	$w = $in[$i];
#	print "$w\n";
	$count{$w}++;
    }
}

foreach $k (keys %count)
{
    if($count{$k}>=5)
    {
	print $k,"\n";
    }

}
