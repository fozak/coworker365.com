#!/usr/bin/perl

$f = shift @ARGV;
$lex = shift @ARGV;

open(L,$lex);

while(<L>)
{
    chop;
    $lex{$_} = 1;
}

open(F,$f);

while(<F>)
{
    chop;
    s/^ *//g;
    s/ *$//g;
    @in = split(/\s+/);
    $n = 0 + @in;
    for($i=0;$i<$n;$i+=2)
    {
	print " " if($i>0);
	$w = $in[$i];
	if($lex{$w} == 1)
	{
	    print "$w ",$in[$i+1];
	}
	else
	{
#	    $c1 = substr($w,0,1);
#	    if((($c1 cmp 'A') >= 0) && (($c1 cmp 'Z') <= 0))
# 	    {
#		$c1 = "A";
#	    }
#	    elsif((($c1 cmp 'a') >= 0) && (($c1 cmp 'z') <= 0))
#	    {
#		$c1 = "a";
#	    }
#	    elsif((($c1 cmp '0') >= 0) && (($c1 cmp '9') <= 0))
#	    {
#		$c1 = "0";
#	    }
#	    else
#	    {
#		$c1 = "-";
#	    }
	    $c1 = "A";
	    print "UNK$c1 ",$in[$i+1];
	}
    }
    print "\n";
}
