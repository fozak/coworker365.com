#!/usr/bin/perl

$f = shift @ARGV;

open(F,$f);

while(<>)
{
#    print;
    chop;
    s/ *$//g;
    s/^ *//g;
    @in = split(/\s+/);
    $n = 0 + @in;
    for($i=1;$i<=$n+1;$i+=2)
    {
	if($i==1)
	{
	    $tm2 = "#S1";
	    $tm1 = "#S2";
	}
	elsif($i==3)
	{
	    $tm2 = "#S2";
	    $tm1 = $in[1];
	}
	else
	{
	    $tm2 = $in[$i-4];
	    $tm1 = $in[$i-2];
	}
	if($i>=$n)
	{
	    $t = "#END";
	}
	else
	{
	    $t = $in[$i];
	}

	print "NUMER $tm2 $tm1 $t\n";
	print "NUMER $tm1 $t\n";
	print "NUMER $t\n";
	print "DENOM $tm2 $tm1\n";
	print "DENOM $tm1\n";
	print "DENOM BLANK\n";
    }
    for($i=1;$i<=$n;$i+=2)
    {
	print "WORDTAG1 $in[$i] $in[$i-1]\n";
	print "WORDTAG2 $in[$i]\n";

    }
}
