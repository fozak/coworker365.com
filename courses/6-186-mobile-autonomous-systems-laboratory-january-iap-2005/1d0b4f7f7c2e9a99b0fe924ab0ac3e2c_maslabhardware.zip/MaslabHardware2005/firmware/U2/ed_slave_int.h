#pragma fastcall16 ED_SLAVE_init
#pragma fastcall16 ED_SLAVE_isData
#pragma fastcall16 ED_SLAVE_getData
#pragma fastcall16 ED_SLAVE_putData

extern char ED_SLAVE_init(void);
extern char ED_SLAVE_isData(void);
extern char ED_SLAVE_getData(void);
extern void ED_SLAVE_putData(char c);

/* If you regenerate the application, you must replace InlinePutChar with this:

   macro InLinePutChar( Source )
   call _ED_SLAVE_putData
   endm

*/