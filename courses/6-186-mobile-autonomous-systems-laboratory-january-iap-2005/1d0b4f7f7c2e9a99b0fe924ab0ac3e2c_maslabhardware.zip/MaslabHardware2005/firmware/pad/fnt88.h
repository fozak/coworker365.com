#ifndef _FNT88_H
#define _FNT88_H
extern const unsigned char fnt88[];
#endif
