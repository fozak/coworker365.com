#ifndef _UTIL_H
#define _UTIL_H

// Convert the argument which is an ASCII hexidecimal character
// to an integer. i.e., c is '0'-'9' or 'A-F' or 'a-f'.
unsigned char ctoi(char c);

// interpret /len/ bytes as a hexidecimal number and return its
// value.
int stoi(char *b, unsigned char len);
int stoi2(char *b, unsigned char len);

// convert an integer [0,15] into a hex character ['0'-'9', 'A'-'F']
char itoh(unsigned char v);

int abs(int v);

int sgn(int v);

#endif
