#ifndef _ORCSPLASH_H
#define _ORCSPLASH_H

extern const unsigned char orcsplash[];

#endif