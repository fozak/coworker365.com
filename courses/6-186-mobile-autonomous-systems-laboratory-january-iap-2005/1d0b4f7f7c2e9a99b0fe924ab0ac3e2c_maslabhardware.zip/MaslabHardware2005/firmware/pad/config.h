#ifndef _CONFIG_H
#define _CONFIG_H

#define FLASHBLOCKNUMBER 511

typedef struct
{
	int joycx, joycy;
	int joyxmin, joyxmax, joyymin, joyymax;

	int batsensedivide;
} params_t;

void loadPrefs(void);
unsigned char savePrefs(void);

#endif