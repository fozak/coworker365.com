#include "util.h"

unsigned char ctoi(char c)
{
	if (c>='0' && c<='9')
		return c-'0';
	
	if (c>='A' && c<='F')
		return c-'A'+10;
		
	if (c>='a' && c<='f')
		return c-'a'+10;
	
	return 0;
}

int stoi(char *b, unsigned char len)
{
	int acc;
	
	acc=0;
	
	while (len!=0)
		{
		acc=acc*16+ctoi(*b);
		len--;
		b++;
		}	

	return acc;
}


int stoi2(char *b, unsigned char len)
{
	int acc;
	
	acc=0;
	
	while (len!=0)
		{
		acc=(acc<<4)+ctoi(*b);
		len--;
		b++;
		}	

	return acc;
}

char itoh(unsigned char v)
{
	if (v<10)
		return v+'0';
	return v+55;
}

int abs(int v)
{
	if (v<0)
		return -v;
	return v;
}

int sgn(int v)
{
	if (v<0)
		return -1;
	return 1;
}