#ifndef _ERROR_H
#define _ERROR_H

#define ESUCCESS    0
#define EBADPORT    1
#define EBADPARAM   2
#define EUNKNOWNCMD 3

#endif