#ifndef _FNT58_H
#define _FNT58_H
extern const unsigned char fnt58[];
#endif
