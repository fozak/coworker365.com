#pragma fastcall16 ED_HOST_init
#pragma fastcall16 ED_HOST_isData
#pragma fastcall16 ED_HOST_getData
#pragma fastcall16 ED_HOST_putData

extern char ED_HOST_init(void);
extern char ED_HOST_isData(void);
extern char ED_HOST_getData(void);
extern void ED_HOST_putData(char c);

extern unsigned char ED_HOST_fStatus;

/* If you regenerate the application, you must replace InlinePutChar with this:

   macro InLinePutChar( Source )
   call _ED_HOST_putData
   endm

*/