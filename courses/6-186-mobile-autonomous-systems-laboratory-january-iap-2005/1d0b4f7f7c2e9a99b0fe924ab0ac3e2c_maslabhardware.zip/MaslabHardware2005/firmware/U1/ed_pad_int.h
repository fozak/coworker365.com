#pragma fastcall16 ED_PAD_init
#pragma fastcall16 ED_PAD_isData
#pragma fastcall16 ED_PAD_getData
#pragma fastcall16 ED_PAD_putData

extern char ED_PAD_init(void);
extern char ED_PAD_isData(void);
extern char ED_PAD_getData(void);
extern void ED_PAD_putData(char c);

extern unsigned char ED_PAD_fStatus;

/* If you regenerate the application, you must replace InlinePutChar with this:

   macro InLinePutChar( Source )
   call _ED_PAD_putData
   endm

*/