#ifndef _UTIL_H
#define _UTIL_H

short charToInt(char c);
int char2ToInt(char *b);
int char4ToInt(char *buf);

#endif
