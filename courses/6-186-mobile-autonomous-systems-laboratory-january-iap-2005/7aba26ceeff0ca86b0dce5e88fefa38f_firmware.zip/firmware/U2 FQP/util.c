#include "util.h"

short charToInt(char c)
{
	if (c>='A' && c<='F')
		return c-'A'+10;
	if (c>='a' && c<='f')
		return c-'a'+10;
	if (c>='0' && c<='9')
		return c-'0';
	return -1;
}

int char2ToInt(char *buf)
{
	short a,b;
	
	a=charToInt(buf[0]);
	b=charToInt(buf[1]);
	
	if (a<0 || b<0)
		return -1;
	
	return a*16+b;
}

int char4ToInt(char *buf)
{
	short a;
	int tot;
	unsigned char c;
	
	tot=0;
	for (c=0;c<4;c++)
	{
		a=charToInt(buf[c]);
		if (a<0)
			return 0;
		
		tot=tot*16+a;
	}
	
	return tot;
}
