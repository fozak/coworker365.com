#ifndef _QPASM_H
#define _QPASM_H

extern unsigned char QP0A_readDirect(void);
extern unsigned char QP0B_readDirect(void);
extern unsigned char QP1A_readDirect(void);
extern unsigned char QP1B_readDirect(void);

#pragma fastcall QP0A_readDirect
#pragma fastcall QP0B_readDirect
#pragma fastcall QP1A_readDirect
#pragma fastcall QP1B_readDirect

#endif
