#include "slave.h"
#include "main.h"

unsigned char selftest(void)
{
	unsigned char trials;
	
	for (trials=0;trials<3;trials++)
	{
		slavestate[0]=0;
		
		slave_requeststate();
	
		if (slavestate[0]==0xED && slavestate[1]>30)
			return 1;
	}
	
	// DO THIS!
	return 0;
}
