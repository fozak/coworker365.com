// A0 address and mask defines
#pragma	ioport	A0_Data_ADDR:	0x0
BYTE			A0_Data_ADDR;
#pragma	ioport	A0_DriveMode_0_ADDR:	0x100
BYTE			A0_DriveMode_0_ADDR;
#pragma	ioport	A0_DriveMode_1_ADDR:	0x101
BYTE			A0_DriveMode_1_ADDR;
#pragma	ioport	A0_DriveMode_2_ADDR:	0x3
BYTE			A0_DriveMode_2_ADDR;
#pragma	ioport	A0_GlobalSelect_ADDR:	0x2
BYTE			A0_GlobalSelect_ADDR;
#pragma	ioport	A0_IntCtrl_0_ADDR:	0x102
BYTE			A0_IntCtrl_0_ADDR;
#pragma	ioport	A0_IntCtrl_1_ADDR:	0x103
BYTE			A0_IntCtrl_1_ADDR;
#pragma	ioport	A0_IntEn_ADDR:	0x1
BYTE			A0_IntEn_ADDR;
#define A0_MASK 0x1
// A1 address and mask defines
#pragma	ioport	A1_Data_ADDR:	0x0
BYTE			A1_Data_ADDR;
#pragma	ioport	A1_DriveMode_0_ADDR:	0x100
BYTE			A1_DriveMode_0_ADDR;
#pragma	ioport	A1_DriveMode_1_ADDR:	0x101
BYTE			A1_DriveMode_1_ADDR;
#pragma	ioport	A1_DriveMode_2_ADDR:	0x3
BYTE			A1_DriveMode_2_ADDR;
#pragma	ioport	A1_GlobalSelect_ADDR:	0x2
BYTE			A1_GlobalSelect_ADDR;
#pragma	ioport	A1_IntCtrl_0_ADDR:	0x102
BYTE			A1_IntCtrl_0_ADDR;
#pragma	ioport	A1_IntCtrl_1_ADDR:	0x103
BYTE			A1_IntCtrl_1_ADDR;
#pragma	ioport	A1_IntEn_ADDR:	0x1
BYTE			A1_IntEn_ADDR;
#define A1_MASK 0x2
// A2 address and mask defines
#pragma	ioport	A2_Data_ADDR:	0x0
BYTE			A2_Data_ADDR;
#pragma	ioport	A2_DriveMode_0_ADDR:	0x100
BYTE			A2_DriveMode_0_ADDR;
#pragma	ioport	A2_DriveMode_1_ADDR:	0x101
BYTE			A2_DriveMode_1_ADDR;
#pragma	ioport	A2_DriveMode_2_ADDR:	0x3
BYTE			A2_DriveMode_2_ADDR;
#pragma	ioport	A2_GlobalSelect_ADDR:	0x2
BYTE			A2_GlobalSelect_ADDR;
#pragma	ioport	A2_IntCtrl_0_ADDR:	0x102
BYTE			A2_IntCtrl_0_ADDR;
#pragma	ioport	A2_IntCtrl_1_ADDR:	0x103
BYTE			A2_IntCtrl_1_ADDR;
#pragma	ioport	A2_IntEn_ADDR:	0x1
BYTE			A2_IntEn_ADDR;
#define A2_MASK 0x4
// A3 address and mask defines
#pragma	ioport	A3_Data_ADDR:	0x0
BYTE			A3_Data_ADDR;
#pragma	ioport	A3_DriveMode_0_ADDR:	0x100
BYTE			A3_DriveMode_0_ADDR;
#pragma	ioport	A3_DriveMode_1_ADDR:	0x101
BYTE			A3_DriveMode_1_ADDR;
#pragma	ioport	A3_DriveMode_2_ADDR:	0x3
BYTE			A3_DriveMode_2_ADDR;
#pragma	ioport	A3_GlobalSelect_ADDR:	0x2
BYTE			A3_GlobalSelect_ADDR;
#pragma	ioport	A3_IntCtrl_0_ADDR:	0x102
BYTE			A3_IntCtrl_0_ADDR;
#pragma	ioport	A3_IntCtrl_1_ADDR:	0x103
BYTE			A3_IntCtrl_1_ADDR;
#pragma	ioport	A3_IntEn_ADDR:	0x1
BYTE			A3_IntEn_ADDR;
#define A3_MASK 0x8
// A4 address and mask defines
#pragma	ioport	A4_Data_ADDR:	0x0
BYTE			A4_Data_ADDR;
#pragma	ioport	A4_DriveMode_0_ADDR:	0x100
BYTE			A4_DriveMode_0_ADDR;
#pragma	ioport	A4_DriveMode_1_ADDR:	0x101
BYTE			A4_DriveMode_1_ADDR;
#pragma	ioport	A4_DriveMode_2_ADDR:	0x3
BYTE			A4_DriveMode_2_ADDR;
#pragma	ioport	A4_GlobalSelect_ADDR:	0x2
BYTE			A4_GlobalSelect_ADDR;
#pragma	ioport	A4_IntCtrl_0_ADDR:	0x102
BYTE			A4_IntCtrl_0_ADDR;
#pragma	ioport	A4_IntCtrl_1_ADDR:	0x103
BYTE			A4_IntCtrl_1_ADDR;
#pragma	ioport	A4_IntEn_ADDR:	0x1
BYTE			A4_IntEn_ADDR;
#define A4_MASK 0x10
// A5 address and mask defines
#pragma	ioport	A5_Data_ADDR:	0x0
BYTE			A5_Data_ADDR;
#pragma	ioport	A5_DriveMode_0_ADDR:	0x100
BYTE			A5_DriveMode_0_ADDR;
#pragma	ioport	A5_DriveMode_1_ADDR:	0x101
BYTE			A5_DriveMode_1_ADDR;
#pragma	ioport	A5_DriveMode_2_ADDR:	0x3
BYTE			A5_DriveMode_2_ADDR;
#pragma	ioport	A5_GlobalSelect_ADDR:	0x2
BYTE			A5_GlobalSelect_ADDR;
#pragma	ioport	A5_IntCtrl_0_ADDR:	0x102
BYTE			A5_IntCtrl_0_ADDR;
#pragma	ioport	A5_IntCtrl_1_ADDR:	0x103
BYTE			A5_IntCtrl_1_ADDR;
#pragma	ioport	A5_IntEn_ADDR:	0x1
BYTE			A5_IntEn_ADDR;
#define A5_MASK 0x20
// A6 address and mask defines
#pragma	ioport	A6_Data_ADDR:	0x0
BYTE			A6_Data_ADDR;
#pragma	ioport	A6_DriveMode_0_ADDR:	0x100
BYTE			A6_DriveMode_0_ADDR;
#pragma	ioport	A6_DriveMode_1_ADDR:	0x101
BYTE			A6_DriveMode_1_ADDR;
#pragma	ioport	A6_DriveMode_2_ADDR:	0x3
BYTE			A6_DriveMode_2_ADDR;
#pragma	ioport	A6_GlobalSelect_ADDR:	0x2
BYTE			A6_GlobalSelect_ADDR;
#pragma	ioport	A6_IntCtrl_0_ADDR:	0x102
BYTE			A6_IntCtrl_0_ADDR;
#pragma	ioport	A6_IntCtrl_1_ADDR:	0x103
BYTE			A6_IntCtrl_1_ADDR;
#pragma	ioport	A6_IntEn_ADDR:	0x1
BYTE			A6_IntEn_ADDR;
#define A6_MASK 0x40
// A7 address and mask defines
#pragma	ioport	A7_Data_ADDR:	0x0
BYTE			A7_Data_ADDR;
#pragma	ioport	A7_DriveMode_0_ADDR:	0x100
BYTE			A7_DriveMode_0_ADDR;
#pragma	ioport	A7_DriveMode_1_ADDR:	0x101
BYTE			A7_DriveMode_1_ADDR;
#pragma	ioport	A7_DriveMode_2_ADDR:	0x3
BYTE			A7_DriveMode_2_ADDR;
#pragma	ioport	A7_GlobalSelect_ADDR:	0x2
BYTE			A7_GlobalSelect_ADDR;
#pragma	ioport	A7_IntCtrl_0_ADDR:	0x102
BYTE			A7_IntCtrl_0_ADDR;
#pragma	ioport	A7_IntCtrl_1_ADDR:	0x103
BYTE			A7_IntCtrl_1_ADDR;
#pragma	ioport	A7_IntEn_ADDR:	0x1
BYTE			A7_IntEn_ADDR;
#define A7_MASK 0x80
// I2Cm_1SDA_Pin address and mask defines
#pragma	ioport	I2Cm_1SDA_Pin_Data_ADDR:	0x4
BYTE			I2Cm_1SDA_Pin_Data_ADDR;
#pragma	ioport	I2Cm_1SDA_Pin_DriveMode_0_ADDR:	0x104
BYTE			I2Cm_1SDA_Pin_DriveMode_0_ADDR;
#pragma	ioport	I2Cm_1SDA_Pin_DriveMode_1_ADDR:	0x105
BYTE			I2Cm_1SDA_Pin_DriveMode_1_ADDR;
#pragma	ioport	I2Cm_1SDA_Pin_DriveMode_2_ADDR:	0x7
BYTE			I2Cm_1SDA_Pin_DriveMode_2_ADDR;
#pragma	ioport	I2Cm_1SDA_Pin_GlobalSelect_ADDR:	0x6
BYTE			I2Cm_1SDA_Pin_GlobalSelect_ADDR;
#pragma	ioport	I2Cm_1SDA_Pin_IntCtrl_0_ADDR:	0x106
BYTE			I2Cm_1SDA_Pin_IntCtrl_0_ADDR;
#pragma	ioport	I2Cm_1SDA_Pin_IntCtrl_1_ADDR:	0x107
BYTE			I2Cm_1SDA_Pin_IntCtrl_1_ADDR;
#pragma	ioport	I2Cm_1SDA_Pin_IntEn_ADDR:	0x5
BYTE			I2Cm_1SDA_Pin_IntEn_ADDR;
#define I2Cm_1SDA_Pin_MASK 0x1
// I2Cm_1SDA_Pin Shadow defines
//   I2Cm_1SDA_Pin_DataShadow define
extern BYTE Port_1_Data_SHADE;
#define I2Cm_1SDA_Pin_DataShadow (*(unsigned char*)&Port_1_Data_SHADE)
//   I2Cm_1SDA_Pin_DriveMode_0Shadow define
extern BYTE Port_1_DriveMode_0_SHADE;
#define I2Cm_1SDA_Pin_DriveMode_0Shadow (*(unsigned char*)&Port_1_DriveMode_0_SHADE)
//   I2Cm_1SDA_Pin_DriveMode_1Shadow define
extern BYTE Port_1_DriveMode_1_SHADE;
#define I2Cm_1SDA_Pin_DriveMode_1Shadow (*(unsigned char*)&Port_1_DriveMode_1_SHADE)
// I2Cm_1SCL_Pin address and mask defines
#pragma	ioport	I2Cm_1SCL_Pin_Data_ADDR:	0x4
BYTE			I2Cm_1SCL_Pin_Data_ADDR;
#pragma	ioport	I2Cm_1SCL_Pin_DriveMode_0_ADDR:	0x104
BYTE			I2Cm_1SCL_Pin_DriveMode_0_ADDR;
#pragma	ioport	I2Cm_1SCL_Pin_DriveMode_1_ADDR:	0x105
BYTE			I2Cm_1SCL_Pin_DriveMode_1_ADDR;
#pragma	ioport	I2Cm_1SCL_Pin_DriveMode_2_ADDR:	0x7
BYTE			I2Cm_1SCL_Pin_DriveMode_2_ADDR;
#pragma	ioport	I2Cm_1SCL_Pin_GlobalSelect_ADDR:	0x6
BYTE			I2Cm_1SCL_Pin_GlobalSelect_ADDR;
#pragma	ioport	I2Cm_1SCL_Pin_IntCtrl_0_ADDR:	0x106
BYTE			I2Cm_1SCL_Pin_IntCtrl_0_ADDR;
#pragma	ioport	I2Cm_1SCL_Pin_IntCtrl_1_ADDR:	0x107
BYTE			I2Cm_1SCL_Pin_IntCtrl_1_ADDR;
#pragma	ioport	I2Cm_1SCL_Pin_IntEn_ADDR:	0x5
BYTE			I2Cm_1SCL_Pin_IntEn_ADDR;
#define I2Cm_1SCL_Pin_MASK 0x2
// I2Cm_1SCL_Pin Shadow defines
//   I2Cm_1SCL_Pin_DataShadow define
extern BYTE Port_1_Data_SHADE;
#define I2Cm_1SCL_Pin_DataShadow (*(unsigned char*)&Port_1_Data_SHADE)
//   I2Cm_1SCL_Pin_DriveMode_0Shadow define
extern BYTE Port_1_DriveMode_0_SHADE;
#define I2Cm_1SCL_Pin_DriveMode_0Shadow (*(unsigned char*)&Port_1_DriveMode_0_SHADE)
//   I2Cm_1SCL_Pin_DriveMode_1Shadow define
extern BYTE Port_1_DriveMode_1_SHADE;
#define I2Cm_1SCL_Pin_DriveMode_1Shadow (*(unsigned char*)&Port_1_DriveMode_1_SHADE)
// HOST_RX address and mask defines
#pragma	ioport	HOST_RX_Data_ADDR:	0x4
BYTE			HOST_RX_Data_ADDR;
#pragma	ioport	HOST_RX_DriveMode_0_ADDR:	0x104
BYTE			HOST_RX_DriveMode_0_ADDR;
#pragma	ioport	HOST_RX_DriveMode_1_ADDR:	0x105
BYTE			HOST_RX_DriveMode_1_ADDR;
#pragma	ioport	HOST_RX_DriveMode_2_ADDR:	0x7
BYTE			HOST_RX_DriveMode_2_ADDR;
#pragma	ioport	HOST_RX_GlobalSelect_ADDR:	0x6
BYTE			HOST_RX_GlobalSelect_ADDR;
#pragma	ioport	HOST_RX_IntCtrl_0_ADDR:	0x106
BYTE			HOST_RX_IntCtrl_0_ADDR;
#pragma	ioport	HOST_RX_IntCtrl_1_ADDR:	0x107
BYTE			HOST_RX_IntCtrl_1_ADDR;
#pragma	ioport	HOST_RX_IntEn_ADDR:	0x5
BYTE			HOST_RX_IntEn_ADDR;
#define HOST_RX_MASK 0x4
// HOST_RX Shadow defines
//   HOST_RX_DataShadow define
extern BYTE Port_1_Data_SHADE;
#define HOST_RX_DataShadow (*(unsigned char*)&Port_1_Data_SHADE)
//   HOST_RX_DriveMode_0Shadow define
extern BYTE Port_1_DriveMode_0_SHADE;
#define HOST_RX_DriveMode_0Shadow (*(unsigned char*)&Port_1_DriveMode_0_SHADE)
//   HOST_RX_DriveMode_1Shadow define
extern BYTE Port_1_DriveMode_1_SHADE;
#define HOST_RX_DriveMode_1Shadow (*(unsigned char*)&Port_1_DriveMode_1_SHADE)
// HOST_TX address and mask defines
#pragma	ioport	HOST_TX_Data_ADDR:	0x4
BYTE			HOST_TX_Data_ADDR;
#pragma	ioport	HOST_TX_DriveMode_0_ADDR:	0x104
BYTE			HOST_TX_DriveMode_0_ADDR;
#pragma	ioport	HOST_TX_DriveMode_1_ADDR:	0x105
BYTE			HOST_TX_DriveMode_1_ADDR;
#pragma	ioport	HOST_TX_DriveMode_2_ADDR:	0x7
BYTE			HOST_TX_DriveMode_2_ADDR;
#pragma	ioport	HOST_TX_GlobalSelect_ADDR:	0x6
BYTE			HOST_TX_GlobalSelect_ADDR;
#pragma	ioport	HOST_TX_IntCtrl_0_ADDR:	0x106
BYTE			HOST_TX_IntCtrl_0_ADDR;
#pragma	ioport	HOST_TX_IntCtrl_1_ADDR:	0x107
BYTE			HOST_TX_IntCtrl_1_ADDR;
#pragma	ioport	HOST_TX_IntEn_ADDR:	0x5
BYTE			HOST_TX_IntEn_ADDR;
#define HOST_TX_MASK 0x8
// HOST_TX Shadow defines
//   HOST_TX_DataShadow define
extern BYTE Port_1_Data_SHADE;
#define HOST_TX_DataShadow (*(unsigned char*)&Port_1_Data_SHADE)
//   HOST_TX_DriveMode_0Shadow define
extern BYTE Port_1_DriveMode_0_SHADE;
#define HOST_TX_DriveMode_0Shadow (*(unsigned char*)&Port_1_DriveMode_0_SHADE)
//   HOST_TX_DriveMode_1Shadow define
extern BYTE Port_1_DriveMode_1_SHADE;
#define HOST_TX_DriveMode_1Shadow (*(unsigned char*)&Port_1_DriveMode_1_SHADE)
// PAD_RX address and mask defines
#pragma	ioport	PAD_RX_Data_ADDR:	0x4
BYTE			PAD_RX_Data_ADDR;
#pragma	ioport	PAD_RX_DriveMode_0_ADDR:	0x104
BYTE			PAD_RX_DriveMode_0_ADDR;
#pragma	ioport	PAD_RX_DriveMode_1_ADDR:	0x105
BYTE			PAD_RX_DriveMode_1_ADDR;
#pragma	ioport	PAD_RX_DriveMode_2_ADDR:	0x7
BYTE			PAD_RX_DriveMode_2_ADDR;
#pragma	ioport	PAD_RX_GlobalSelect_ADDR:	0x6
BYTE			PAD_RX_GlobalSelect_ADDR;
#pragma	ioport	PAD_RX_IntCtrl_0_ADDR:	0x106
BYTE			PAD_RX_IntCtrl_0_ADDR;
#pragma	ioport	PAD_RX_IntCtrl_1_ADDR:	0x107
BYTE			PAD_RX_IntCtrl_1_ADDR;
#pragma	ioport	PAD_RX_IntEn_ADDR:	0x5
BYTE			PAD_RX_IntEn_ADDR;
#define PAD_RX_MASK 0x10
// PAD_RX Shadow defines
//   PAD_RX_DataShadow define
extern BYTE Port_1_Data_SHADE;
#define PAD_RX_DataShadow (*(unsigned char*)&Port_1_Data_SHADE)
//   PAD_RX_DriveMode_0Shadow define
extern BYTE Port_1_DriveMode_0_SHADE;
#define PAD_RX_DriveMode_0Shadow (*(unsigned char*)&Port_1_DriveMode_0_SHADE)
//   PAD_RX_DriveMode_1Shadow define
extern BYTE Port_1_DriveMode_1_SHADE;
#define PAD_RX_DriveMode_1Shadow (*(unsigned char*)&Port_1_DriveMode_1_SHADE)
// PAD_TX address and mask defines
#pragma	ioport	PAD_TX_Data_ADDR:	0x4
BYTE			PAD_TX_Data_ADDR;
#pragma	ioport	PAD_TX_DriveMode_0_ADDR:	0x104
BYTE			PAD_TX_DriveMode_0_ADDR;
#pragma	ioport	PAD_TX_DriveMode_1_ADDR:	0x105
BYTE			PAD_TX_DriveMode_1_ADDR;
#pragma	ioport	PAD_TX_DriveMode_2_ADDR:	0x7
BYTE			PAD_TX_DriveMode_2_ADDR;
#pragma	ioport	PAD_TX_GlobalSelect_ADDR:	0x6
BYTE			PAD_TX_GlobalSelect_ADDR;
#pragma	ioport	PAD_TX_IntCtrl_0_ADDR:	0x106
BYTE			PAD_TX_IntCtrl_0_ADDR;
#pragma	ioport	PAD_TX_IntCtrl_1_ADDR:	0x107
BYTE			PAD_TX_IntCtrl_1_ADDR;
#pragma	ioport	PAD_TX_IntEn_ADDR:	0x5
BYTE			PAD_TX_IntEn_ADDR;
#define PAD_TX_MASK 0x20
// PAD_TX Shadow defines
//   PAD_TX_DataShadow define
extern BYTE Port_1_Data_SHADE;
#define PAD_TX_DataShadow (*(unsigned char*)&Port_1_Data_SHADE)
//   PAD_TX_DriveMode_0Shadow define
extern BYTE Port_1_DriveMode_0_SHADE;
#define PAD_TX_DriveMode_0Shadow (*(unsigned char*)&Port_1_DriveMode_0_SHADE)
//   PAD_TX_DriveMode_1Shadow define
extern BYTE Port_1_DriveMode_1_SHADE;
#define PAD_TX_DriveMode_1Shadow (*(unsigned char*)&Port_1_DriveMode_1_SHADE)
// SLAVE_RX address and mask defines
#pragma	ioport	SLAVE_RX_Data_ADDR:	0x4
BYTE			SLAVE_RX_Data_ADDR;
#pragma	ioport	SLAVE_RX_DriveMode_0_ADDR:	0x104
BYTE			SLAVE_RX_DriveMode_0_ADDR;
#pragma	ioport	SLAVE_RX_DriveMode_1_ADDR:	0x105
BYTE			SLAVE_RX_DriveMode_1_ADDR;
#pragma	ioport	SLAVE_RX_DriveMode_2_ADDR:	0x7
BYTE			SLAVE_RX_DriveMode_2_ADDR;
#pragma	ioport	SLAVE_RX_GlobalSelect_ADDR:	0x6
BYTE			SLAVE_RX_GlobalSelect_ADDR;
#pragma	ioport	SLAVE_RX_IntCtrl_0_ADDR:	0x106
BYTE			SLAVE_RX_IntCtrl_0_ADDR;
#pragma	ioport	SLAVE_RX_IntCtrl_1_ADDR:	0x107
BYTE			SLAVE_RX_IntCtrl_1_ADDR;
#pragma	ioport	SLAVE_RX_IntEn_ADDR:	0x5
BYTE			SLAVE_RX_IntEn_ADDR;
#define SLAVE_RX_MASK 0x40
// SLAVE_RX Shadow defines
//   SLAVE_RX_DataShadow define
extern BYTE Port_1_Data_SHADE;
#define SLAVE_RX_DataShadow (*(unsigned char*)&Port_1_Data_SHADE)
//   SLAVE_RX_DriveMode_0Shadow define
extern BYTE Port_1_DriveMode_0_SHADE;
#define SLAVE_RX_DriveMode_0Shadow (*(unsigned char*)&Port_1_DriveMode_0_SHADE)
//   SLAVE_RX_DriveMode_1Shadow define
extern BYTE Port_1_DriveMode_1_SHADE;
#define SLAVE_RX_DriveMode_1Shadow (*(unsigned char*)&Port_1_DriveMode_1_SHADE)
// SLAVE_TX address and mask defines
#pragma	ioport	SLAVE_TX_Data_ADDR:	0x4
BYTE			SLAVE_TX_Data_ADDR;
#pragma	ioport	SLAVE_TX_DriveMode_0_ADDR:	0x104
BYTE			SLAVE_TX_DriveMode_0_ADDR;
#pragma	ioport	SLAVE_TX_DriveMode_1_ADDR:	0x105
BYTE			SLAVE_TX_DriveMode_1_ADDR;
#pragma	ioport	SLAVE_TX_DriveMode_2_ADDR:	0x7
BYTE			SLAVE_TX_DriveMode_2_ADDR;
#pragma	ioport	SLAVE_TX_GlobalSelect_ADDR:	0x6
BYTE			SLAVE_TX_GlobalSelect_ADDR;
#pragma	ioport	SLAVE_TX_IntCtrl_0_ADDR:	0x106
BYTE			SLAVE_TX_IntCtrl_0_ADDR;
#pragma	ioport	SLAVE_TX_IntCtrl_1_ADDR:	0x107
BYTE			SLAVE_TX_IntCtrl_1_ADDR;
#pragma	ioport	SLAVE_TX_IntEn_ADDR:	0x5
BYTE			SLAVE_TX_IntEn_ADDR;
#define SLAVE_TX_MASK 0x80
// SLAVE_TX Shadow defines
//   SLAVE_TX_DataShadow define
extern BYTE Port_1_Data_SHADE;
#define SLAVE_TX_DataShadow (*(unsigned char*)&Port_1_Data_SHADE)
//   SLAVE_TX_DriveMode_0Shadow define
extern BYTE Port_1_DriveMode_0_SHADE;
#define SLAVE_TX_DriveMode_0Shadow (*(unsigned char*)&Port_1_DriveMode_0_SHADE)
//   SLAVE_TX_DriveMode_1Shadow define
extern BYTE Port_1_DriveMode_1_SHADE;
#define SLAVE_TX_DriveMode_1Shadow (*(unsigned char*)&Port_1_DriveMode_1_SHADE)
// D0 address and mask defines
#pragma	ioport	D0_Data_ADDR:	0x8
BYTE			D0_Data_ADDR;
#pragma	ioport	D0_DriveMode_0_ADDR:	0x108
BYTE			D0_DriveMode_0_ADDR;
#pragma	ioport	D0_DriveMode_1_ADDR:	0x109
BYTE			D0_DriveMode_1_ADDR;
#pragma	ioport	D0_DriveMode_2_ADDR:	0xb
BYTE			D0_DriveMode_2_ADDR;
#pragma	ioport	D0_GlobalSelect_ADDR:	0xa
BYTE			D0_GlobalSelect_ADDR;
#pragma	ioport	D0_IntCtrl_0_ADDR:	0x10a
BYTE			D0_IntCtrl_0_ADDR;
#pragma	ioport	D0_IntCtrl_1_ADDR:	0x10b
BYTE			D0_IntCtrl_1_ADDR;
#pragma	ioport	D0_IntEn_ADDR:	0x9
BYTE			D0_IntEn_ADDR;
#define D0_MASK 0x1
// D1 address and mask defines
#pragma	ioport	D1_Data_ADDR:	0x8
BYTE			D1_Data_ADDR;
#pragma	ioport	D1_DriveMode_0_ADDR:	0x108
BYTE			D1_DriveMode_0_ADDR;
#pragma	ioport	D1_DriveMode_1_ADDR:	0x109
BYTE			D1_DriveMode_1_ADDR;
#pragma	ioport	D1_DriveMode_2_ADDR:	0xb
BYTE			D1_DriveMode_2_ADDR;
#pragma	ioport	D1_GlobalSelect_ADDR:	0xa
BYTE			D1_GlobalSelect_ADDR;
#pragma	ioport	D1_IntCtrl_0_ADDR:	0x10a
BYTE			D1_IntCtrl_0_ADDR;
#pragma	ioport	D1_IntCtrl_1_ADDR:	0x10b
BYTE			D1_IntCtrl_1_ADDR;
#pragma	ioport	D1_IntEn_ADDR:	0x9
BYTE			D1_IntEn_ADDR;
#define D1_MASK 0x2
// D2 address and mask defines
#pragma	ioport	D2_Data_ADDR:	0x8
BYTE			D2_Data_ADDR;
#pragma	ioport	D2_DriveMode_0_ADDR:	0x108
BYTE			D2_DriveMode_0_ADDR;
#pragma	ioport	D2_DriveMode_1_ADDR:	0x109
BYTE			D2_DriveMode_1_ADDR;
#pragma	ioport	D2_DriveMode_2_ADDR:	0xb
BYTE			D2_DriveMode_2_ADDR;
#pragma	ioport	D2_GlobalSelect_ADDR:	0xa
BYTE			D2_GlobalSelect_ADDR;
#pragma	ioport	D2_IntCtrl_0_ADDR:	0x10a
BYTE			D2_IntCtrl_0_ADDR;
#pragma	ioport	D2_IntCtrl_1_ADDR:	0x10b
BYTE			D2_IntCtrl_1_ADDR;
#pragma	ioport	D2_IntEn_ADDR:	0x9
BYTE			D2_IntEn_ADDR;
#define D2_MASK 0x4
// D3 address and mask defines
#pragma	ioport	D3_Data_ADDR:	0x8
BYTE			D3_Data_ADDR;
#pragma	ioport	D3_DriveMode_0_ADDR:	0x108
BYTE			D3_DriveMode_0_ADDR;
#pragma	ioport	D3_DriveMode_1_ADDR:	0x109
BYTE			D3_DriveMode_1_ADDR;
#pragma	ioport	D3_DriveMode_2_ADDR:	0xb
BYTE			D3_DriveMode_2_ADDR;
#pragma	ioport	D3_GlobalSelect_ADDR:	0xa
BYTE			D3_GlobalSelect_ADDR;
#pragma	ioport	D3_IntCtrl_0_ADDR:	0x10a
BYTE			D3_IntCtrl_0_ADDR;
#pragma	ioport	D3_IntCtrl_1_ADDR:	0x10b
BYTE			D3_IntCtrl_1_ADDR;
#pragma	ioport	D3_IntEn_ADDR:	0x9
BYTE			D3_IntEn_ADDR;
#define D3_MASK 0x8
// D4 address and mask defines
#pragma	ioport	D4_Data_ADDR:	0x8
BYTE			D4_Data_ADDR;
#pragma	ioport	D4_DriveMode_0_ADDR:	0x108
BYTE			D4_DriveMode_0_ADDR;
#pragma	ioport	D4_DriveMode_1_ADDR:	0x109
BYTE			D4_DriveMode_1_ADDR;
#pragma	ioport	D4_DriveMode_2_ADDR:	0xb
BYTE			D4_DriveMode_2_ADDR;
#pragma	ioport	D4_GlobalSelect_ADDR:	0xa
BYTE			D4_GlobalSelect_ADDR;
#pragma	ioport	D4_IntCtrl_0_ADDR:	0x10a
BYTE			D4_IntCtrl_0_ADDR;
#pragma	ioport	D4_IntCtrl_1_ADDR:	0x10b
BYTE			D4_IntCtrl_1_ADDR;
#pragma	ioport	D4_IntEn_ADDR:	0x9
BYTE			D4_IntEn_ADDR;
#define D4_MASK 0x10
// D5 address and mask defines
#pragma	ioport	D5_Data_ADDR:	0x8
BYTE			D5_Data_ADDR;
#pragma	ioport	D5_DriveMode_0_ADDR:	0x108
BYTE			D5_DriveMode_0_ADDR;
#pragma	ioport	D5_DriveMode_1_ADDR:	0x109
BYTE			D5_DriveMode_1_ADDR;
#pragma	ioport	D5_DriveMode_2_ADDR:	0xb
BYTE			D5_DriveMode_2_ADDR;
#pragma	ioport	D5_GlobalSelect_ADDR:	0xa
BYTE			D5_GlobalSelect_ADDR;
#pragma	ioport	D5_IntCtrl_0_ADDR:	0x10a
BYTE			D5_IntCtrl_0_ADDR;
#pragma	ioport	D5_IntCtrl_1_ADDR:	0x10b
BYTE			D5_IntCtrl_1_ADDR;
#pragma	ioport	D5_IntEn_ADDR:	0x9
BYTE			D5_IntEn_ADDR;
#define D5_MASK 0x20
// D6 address and mask defines
#pragma	ioport	D6_Data_ADDR:	0x8
BYTE			D6_Data_ADDR;
#pragma	ioport	D6_DriveMode_0_ADDR:	0x108
BYTE			D6_DriveMode_0_ADDR;
#pragma	ioport	D6_DriveMode_1_ADDR:	0x109
BYTE			D6_DriveMode_1_ADDR;
#pragma	ioport	D6_DriveMode_2_ADDR:	0xb
BYTE			D6_DriveMode_2_ADDR;
#pragma	ioport	D6_GlobalSelect_ADDR:	0xa
BYTE			D6_GlobalSelect_ADDR;
#pragma	ioport	D6_IntCtrl_0_ADDR:	0x10a
BYTE			D6_IntCtrl_0_ADDR;
#pragma	ioport	D6_IntCtrl_1_ADDR:	0x10b
BYTE			D6_IntCtrl_1_ADDR;
#pragma	ioport	D6_IntEn_ADDR:	0x9
BYTE			D6_IntEn_ADDR;
#define D6_MASK 0x40
// D7 address and mask defines
#pragma	ioport	D7_Data_ADDR:	0x8
BYTE			D7_Data_ADDR;
#pragma	ioport	D7_DriveMode_0_ADDR:	0x108
BYTE			D7_DriveMode_0_ADDR;
#pragma	ioport	D7_DriveMode_1_ADDR:	0x109
BYTE			D7_DriveMode_1_ADDR;
#pragma	ioport	D7_DriveMode_2_ADDR:	0xb
BYTE			D7_DriveMode_2_ADDR;
#pragma	ioport	D7_GlobalSelect_ADDR:	0xa
BYTE			D7_GlobalSelect_ADDR;
#pragma	ioport	D7_IntCtrl_0_ADDR:	0x10a
BYTE			D7_IntCtrl_0_ADDR;
#pragma	ioport	D7_IntCtrl_1_ADDR:	0x10b
BYTE			D7_IntCtrl_1_ADDR;
#pragma	ioport	D7_IntEn_ADDR:	0x9
BYTE			D7_IntEn_ADDR;
#define D7_MASK 0x80
