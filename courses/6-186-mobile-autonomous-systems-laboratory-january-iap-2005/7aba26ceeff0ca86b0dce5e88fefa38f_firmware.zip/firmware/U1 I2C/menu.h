#ifndef _MENU_H
#define _MENU_H

signed char menu(const char *menuname1, const char **menu, 
				 signed char selected);


#endif
