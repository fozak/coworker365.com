#ifndef _SLAVE_H
#define _SLAVE_H

#define SLAVE_TIMEOUT 100L

void slave_requeststate(void);
void slave_allstop(void);

unsigned char slave_chksend(unsigned char chk, unsigned char c);
void slave_packet1(unsigned char b0);
void slave_packet3(unsigned char b0, unsigned char b1, unsigned char b2);
void slave_packet4(unsigned char b0, unsigned char b1, unsigned char b2, unsigned char b3);
void setmotor(unsigned char port, int dirpwm);
int getmotoractualsignedpwm(unsigned char port);
unsigned char getmotoractualpwm(unsigned char port);
unsigned char getmotorgoalpwm(unsigned char port);
unsigned char getmotoractualdir(unsigned char port);
unsigned int getmotorcurrent(unsigned char port);

#endif
