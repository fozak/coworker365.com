#ifndef _CONFIG_H
#define _CONFIG_H

#define FLASHBLOCKNUMBER 511

#define DRIVEMODE_SWAPLR   1
#define DRIVEMODE_LEFTINV  2
#define DRIVEMODE_RIGHTINV 4

typedef struct
{
	int baud; // an index into the "baudmenu" array, 0=115200, 1=500000
	unsigned char drivemode;
	
} params_t;

void loadPrefs(void);		// load prefs from flash and activate them.
unsigned char savePrefs(void);

extern params_t params;

#endif