#ifndef _FNT68_H
#define _FNT68_H
extern const unsigned char fnt68[];
#endif
