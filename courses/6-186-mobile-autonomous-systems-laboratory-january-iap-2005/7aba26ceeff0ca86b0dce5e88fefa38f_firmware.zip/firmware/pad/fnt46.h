#ifndef _FNT46_H
#define _FNT46_H
extern const unsigned char fnt46[];
#endif
