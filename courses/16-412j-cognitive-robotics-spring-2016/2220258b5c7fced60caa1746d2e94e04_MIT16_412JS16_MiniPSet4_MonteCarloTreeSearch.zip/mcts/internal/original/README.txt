The `pset` folder is the pset. The `mcts.py` file holds our implementation
of the six functions that the students need to complete.
