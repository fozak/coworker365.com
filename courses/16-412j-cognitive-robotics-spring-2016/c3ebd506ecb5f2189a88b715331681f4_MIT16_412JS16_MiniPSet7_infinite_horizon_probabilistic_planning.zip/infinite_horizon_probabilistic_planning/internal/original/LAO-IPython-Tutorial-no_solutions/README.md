# LAO-IPython-Tutorial
An IPython notebook for learning and implementing LAO*. 
