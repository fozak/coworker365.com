function prettyfigure()
% enhances the appearance of the plots

ax = gca;
fg = gcf;
set(ax,'Box', 'Off');
set(ax, 'LineWidth',2);
set(ax, 'FontSize', 14);
set(ax, 'YAxisLocation', 'origin');
set(fg, 'Color', 'w');