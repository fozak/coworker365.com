%% Load Data
load('MNISTOCW.mat');
numExamples = size(X,1);

%% Input Layer

a1 = [ones(numExamples,1) X];

%% Hidden Layer

z2 = a1*Theta1';
a2 = sigmoid(z2);
a2 = [ones(numExamples,1) a2];

%% Output Layer

z3 = a2 * Theta2';
a3 = sigmoid(z3);

%% Make prediction

[~,pred] = max(a3,[],2);

%% Accuracy and misclassification error 

Accuracy = 100 * mean(pred == y);
MisclassificationError = 100 - Accuracy; 


%% Confusion matrix
CM = confusionmat(y,pred);
CM(1:11:end)=0;
figure(2)
imagesc(CM)
colorbar





