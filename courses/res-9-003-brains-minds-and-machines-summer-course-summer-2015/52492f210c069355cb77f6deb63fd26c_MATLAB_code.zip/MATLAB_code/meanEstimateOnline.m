% computes the mean value of a set of data through incremental (online)
% estimation, illustrating the use of a for statement

x = 10+10*randn(1,10000);       % possible prizes
 
m=zeros(1,5001);                % store mean estimates
m(1)=90;                        % initial guess
for k = 1:5000                  % loop 5000 times
    h=randsample(10000,1);      % pick value randomly from x distributions
    m(1,k+1)=m(1,k)+(1/(k))*(x(1,h)-m(1,k));    % update rule
end
 
plot(m(2:end));
