% simple script illustrating the use of plot, subplot, and title

x = -6:.5:6;
y = x.^2-4;
figure(1)
subplot(2,1,1)
plot(x,y,'o')
title('Integers and half integers squared')
subplot(2,1,2)
plot(x,x,'o')
title('Integers and half integers')
