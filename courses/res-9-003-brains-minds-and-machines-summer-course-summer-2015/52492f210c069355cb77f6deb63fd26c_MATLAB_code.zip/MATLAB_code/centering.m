function centerData = centering (Data)
% centers the data contained in the input matrix so that
% it has a mean value of 0

[r,c]=size(Data);
xbar = mean(Data,1);
Z = repmat(xbar,r,1);
centerData = Data - Z;

end

