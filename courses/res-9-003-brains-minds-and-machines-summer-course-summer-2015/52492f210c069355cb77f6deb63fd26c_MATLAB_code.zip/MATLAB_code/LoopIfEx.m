% example of a simple if statement with elseif and else clauses

clear s; 			% clears the variable s out of memory 
for A=1:5
	if (A > 3)
		A			% print out the value of A
	elseif (A==3)  	% note syntax: 'A equals 3' is denoted by a double 
                    %     equal sign!
				  % The single = is used only to assign values to variables
					% Confusing these is one of the easiest ways to have an 
                    %     error in your code! 
		s = 'hello'	  % to print and/or assign a text string, put it inside
                    %      single quotation marks
	else			% A equals 1 or 2
		-A          % print out negative of the value of A 
    end             % end of if statement
end                 % end of for loop
