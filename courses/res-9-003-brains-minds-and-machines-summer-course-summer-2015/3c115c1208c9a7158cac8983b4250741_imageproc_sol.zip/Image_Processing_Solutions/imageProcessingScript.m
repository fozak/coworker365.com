%% Simulating spatial processing in the visual pathway with convolution 

%% part 1

% create a simple kernel for 2D convolution
kernel = [0.1 0.3 0.5 0.3 0.1; 0.3 0.7 0.9 0.7 0.3; 0.5 0.9 1.0 0.9 0.5; ...
           0.3 0.7 0.9 0.7 0.3; 0.1 0.3 0.5 0.3 0.1];
       
image = double(imread('coins.png'));        % load coins image

result = conv2(image, kernel, 'valid');     % compute 2D convolution

figure
subplot(1,2,1)                              % display results
imshow(image, [])
subplot(1,2,2)
imshow(result, [])

%% part 2

gauss1 = gauss2D(1.0);                      % create Gaussian kernels
gauss2 = gauss2D(2.0);

result1 = conv2(image, gauss1, 'valid');    % compute 2D convolutions
result2 = conv2(image, gauss2, 'valid');

figure
subplot(1,3,1)                              % display results
imshow(image, [])
subplot(1,3,2)
imshow(result1, [])
subplot(1,3,3)
imshow(result2, [])
 
%% part 3

lap1 = lapGauss(1.0);                       % create Laplacian kernels
lap2 = lapGauss(2.0);

result3 = conv2(image, lap1, 'valid');      % compute 2D convolutions
result4 = conv2(image, lap2, 'valid');

figure
subplot(1,3,1)                              % display results
imshow(image, [])
subplot(1,3,2)
imshow(result3, [])
subplot(1,3,3)
imshow(result4, [])

% display results as a binary image, with negative values shown in
% black and positive values in white
figure
subplot(1,3,1)                              
imshow(image, [])                           
subplot(1,3,2)
imshow(result3, [0 0.001])
subplot(1,3,3)
imshow(result4, [0 0.001])

%% part 4

% convolve the image with Gabor kernels of four different orientations

figure
for orient = 0:3
    gaborK = gabor(2.0, orient*45.0, 4, 0);     % create Gabor kernel
    resultK = conv2(image, gaborK, 'valid');    % compute convolution
    subplot(2,2,orient+1)                       % display results
    imshow(resultK, [])
end


