function kernel = gabor(sigma, orient, lambda, phase)
% kernel = gabor(sigma, orient, lambda, phase)
% returns a matrix containing samples of a Gabor function with an input
% orientation specified in degrees, wavelength lambda, and phase also
% specified in degrees

[x y] = meshgrid(-3*sigma:0.5:3*sigma);     % generate x,y coordinates
scale = -1/(2.0*sigma^2);
xr = x*cosd(orient) + y*sind(orient);       % rotate coordinates by orient
yr = -x*sind(orient) + y*cosd(orient);      % construct Gabor kernel
kernel = exp(scale*(xr.^2 + yr.^2)).*cosd((360/lambda)*xr + phase);

end

