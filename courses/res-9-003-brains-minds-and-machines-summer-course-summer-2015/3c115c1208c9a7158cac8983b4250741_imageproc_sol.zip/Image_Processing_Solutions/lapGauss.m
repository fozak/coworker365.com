function kernel = lapGauss(sigma)
% kernel = lapGauss(sigma)
% returns a matrix containing samples of the Laplacian of a 2D Gaussian 
% with spread given by the input sigma

[x y] = meshgrid(-3*sigma:0.5:3*sigma);    % generate x,y coordinates
scale = -1/(2*sigma^2);                     % construct kernel values
kernel = (1/sigma^2)*(((x.^2 + y.^2)/sigma^2)-2).*exp(scale*(x.^2 + y.^2));

end
