function kernel = gauss2D(sigma)
% kernel = gauss2D(sigma)
% returns a matrix containing samples of a 2D Gaussian with
% spread given by the input sigma

[x y] = meshgrid(-2*sigma:0.5:2*sigma);     % generate x,y coordinates
scale = -1/(2*sigma^2);                     
kernel = exp(scale*(x.^2 + y.^2));          % construct Gaussian kernel

end

